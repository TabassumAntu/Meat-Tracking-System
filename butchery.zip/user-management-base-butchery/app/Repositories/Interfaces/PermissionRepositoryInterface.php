<?php


namespace App\Repositories\Interfaces;


use Illuminate\Http\Response;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

interface PermissionRepositoryInterface extends EloquentRepositoryInterface
{
}
